"""История цен: изменение в ПСТ, чьё оно и пауза после него."""

import datetime as dt
import sys
from pathlib import Path
from types import SimpleNamespace as NS

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "Программа"))

from pricing import pricehistory as H  # noqa: E402
from pricing.recommend import Rec  # noqa: E402


def row(code, mo, cat_a, rec=None, sales3=None):
    return NS(code=code, mo=mo, cat_a=cat_a, rec=rec, sales3=sales3, sales3_qty=None)


def test_change_is_ours_when_it_matches_the_recommendation(tmp_path):
    path = tmp_path / "история цен.json"
    day = dt.date(2026, 9, 1)
    first = [row("1", 1000, 800), row("2", 1000, 800), row("3", 1000, 800)]
    assert H.observe(first, day, path) == 0
    first[0].rec = Rec(840, 0.05, "к цели", "up")
    first[1].rec = Rec(840, 0.05, "к цели", "up")
    assert H.remember_recs(first, day, path) == 2
    # через две недели в ПСТ: первый — как рекомендовали, второй — иначе, третий не меняли
    later = [row("1", 1050, 840), row("2", 1100, 880), row("3", 1000, 800)]
    assert H.observe(later, day + dt.timedelta(days=14), path) == 2
    assert H.last_change("1", path)["by"] == "rec"
    assert H.last_change("2", path)["by"] == "other"
    assert H.last_change("3", path) is None
    assert "по рекомендации" in H.change_text(H.last_change("1", path))
    # пауза: через 30 дней после изменения цену не трогаем, через 100 — можно
    H.annotate(later, 90, day + dt.timedelta(days=44), path)
    assert later[0].frozen and "15.09.2026" in later[0].frozen and not later[2].frozen
    H.annotate(later, 90, day + dt.timedelta(days=120), path)
    assert not later[0].frozen and later[0].last_change
    H.annotate(later, 0, day + dt.timedelta(days=20), path)
    assert not later[0].frozen


def test_recent_sales_are_remembered_by_date(tmp_path):
    path = tmp_path / "история цен.json"
    H.observe([row("1", 1000, 800, sales3=5000)], dt.date(2026, 10, 1), path)
    H.observe([row("1", 1000, 800, sales3=7000)], dt.date(2026, 10, 1), path)
    H.observe([row("1", 1000, 800, sales3=9000)], dt.date(2026, 11, 1), path)
    series = H.load(path)["sales"]["1"]
    assert [p[0] for p in series] == ["2026-10-01", "2026-11-01"] and series[0][2] == 7000


def test_lost_competitor_prices_are_found_between_runs(tmp_path):
    path = tmp_path / "история цен.json"
    best = NS(supplier="Армтек · Владивосток")
    a = NS(code="1", prices={"BREMBO": 100.0}, best={"BREMBO": best})
    b = NS(code="2", prices={"BREMBO": 200.0}, best={"BREMBO": best})
    since, lost = H.track_priced("ADVICS|диски", [a, b], dt.date(2026, 10, 1), path)
    assert since == "" and lost == []
    # тот же день — сравнивать не с чем
    b.prices = {"BREMBO": None}
    assert H.track_priced("ADVICS|диски", [a, b], dt.date(2026, 10, 1), path)[1] == []
    # следующий день: у второго цены нет — потеря относительно 1 октября
    since, lost = H.track_priced("ADVICS|диски", [a, b], dt.date(2026, 10, 2), path)
    assert since == "2026-10-01" and [x["code"] for x in lost] == ["2"] and lost[0]["supplier"].startswith("Армтек")
    # другие настройки цен — свой снимок, без мнимых потерь
    assert H.track_priced("ADVICS|диски|median", [a, b], dt.date(2026, 10, 2), path)[1] == []


def test_cross_articles_under_another_brand_are_suggested():
    from pricing.price_check import article_hints
    from pricing.prices import Offer
    from pricing.sources import CrossRow, norm_article

    arts = [f"24.0122-0{i}" for i in range(6)]
    pf = NS(enabled=True, offers=[Offer("Continental Teves", a, 1000.0 + i, 3, i) for i, a in enumerate(arts)], supplier="Армтек")
    crosses = {("ADVICS", f"A{i}"): {"ATE": [CrossRow(a, norm_article(a), "ATE", True)]} for i, a in enumerate(arts)}
    hints = article_hints([pf], {"ATE": "ATE"}, crosses, set())
    assert hints and hints[0]["brand"] == "Continental Teves" and hints[0]["suggest"] == "ATE" and hints[0]["rows"] == 6
    # случайное совпадение номеров: 8 артикулов LYNX среди тысячи строк MAHLE — не синоним
    lynx = [f"LF{i:04d}" for i in range(80)]
    mahle = NS(enabled=True, supplier="Берг", offers=[Offer("MAHLE", f"OC{i}", 500.0, 1, i) for i in range(1000)]
               + [Offer("MAHLE", a, 500.0, 1, 2000 + i) for i, a in enumerate(lynx[:8])])
    lynx_crosses = {("AVANTECH", f"F{i}"): {"LYNX": [CrossRow(a, norm_article(a), "LYNX", True)]} for i, a in enumerate(lynx)}
    assert article_hints([mahle], {"LYNX": "LYNXAUTO"}, lynx_crosses, set()) == []
    # если под брендом ATE эти артикулы в прайсах тоже есть — это не потеря
    pf.offers += [Offer("ATE", a, 900.0, 1, 10 + i) for i, a in enumerate(arts)]
    assert article_hints([pf], {"ATE": "ATE"}, crosses, set()) == []


def test_stale_currency_rate_is_reported(monkeypatch):
    from pricing import server
    from pricing.settings import Settings

    s = Settings.load(None)
    s.data["currency_rates"] = {"JPY": 0.55, "USD": 81.0}
    s.data["currency_rates_date"] = (dt.date.today() - dt.timedelta(days=45)).isoformat()
    monkeypatch.setattr(server.dynamics, "read_currency",
                        lambda folder: {"rates": {"JPY": {"01.10.2026": 60.0, "15.10.2026": 61.0}, "USD": {"15.10.2026": 81.5}}})
    notes = server.rates_check(Path("."), s)
    texts = " ".join(n["text"] for n in notes)
    assert "JPY" in texts and "USD" not in texts  # иена за 100 единиц: 0,61 против 0,55; доллар в пределах 3%
    assert any(n.get("age") == 45 for n in notes)


def test_compaction_keeps_fresh_dates():
    from pricing import pricearchive as A

    shots = [NS(shot_date=d) for d in ("01.09.2026", "20.09.2026", "29.09.2026", "06.10.2026", "14.10.2026")]
    today = dt.date(2026, 10, 16)
    # старше двух недель — 01.09 и 20.09 и 29.09, но три последние даты остаются всегда
    assert A.plan(shots, today) == ["01.09.2026", "20.09.2026"]
    assert A.plan(shots, today, keep_min=1) == ["01.09.2026", "20.09.2026", "29.09.2026"]
    assert A.plan(shots[:2], today) == []


def test_market_signals_show_who_moved_prices():
    from pricing.insight import market_signals

    comp = NS(key="BREMBO", name="Brembo")
    rows = [NS(code=str(i), prices={"BREMBO": 1060.0 if i < 4 else 1000.0}, competitors=[comp], sales=100) for i in range(10)]
    prev = {"date": "2026-10-10", "items": {str(i): {"BREMBO": [1000.0, "Армтек"]} for i in range(10)}}
    sig = market_signals(rows, prev)
    assert len(sig) == 1 and sig[0]["side"] == "up" and sig[0]["n"] == 4 and sig[0]["of"] == 10
    assert "Brembo поднял цены на 4 из 10" in sig[0]["text"] and "+6,0%" in sig[0]["text"] and "10.10" in sig[0]["text"]
    # двинулись две позиции из десяти — не сигнал
    for r in rows[2:4]:
        r.prices = {"BREMBO": 1000.0}
    assert market_signals(rows, prev) == []
    assert market_signals(rows, None) == []


def test_currency_move_is_a_signal(monkeypatch):
    from pricing import server

    monkeypatch.setattr(server.dynamics, "read_currency",
                        lambda folder: {"rates": {"JPY": {"01.10.2026": 0.60, "16.10.2026": 0.63}, "USD": {"01.10.2026": 81.0, "16.10.2026": 81.5}}})
    rows = [NS(purchase_currency="JPY"), NS(purchase_currency="JPY"), NS(purchase_currency="RUB")]
    sig = server.currency_signals(Path("."), rows)
    assert [s["comp"] for s in sig] == ["JPY"] and sig[0]["n"] == 2 and "+5,0%" in sig[0]["text"]


def test_sales_by_days_take_the_total_and_keep_the_series():
    from pricing.excel import Sheet
    from pricing.sources import classify, read_sales, read_sales_periods

    top = ["Товар", "Артикул", "Код", "01.08.2026 0:00:00", "01.08.2026 0:00:00", "02.08.2026 0:00:00", "02.08.2026 0:00:00", "Итого", "Итого"]
    low = ["Товар", "Артикул", "Код"] + ["00. Количество (шт)", "01. Сумма продажи, руб (отгрузка - возврат)"] * 3
    grid = [["Анализ себестоимости продаж"], ["Начало периода: 01.08.2026"], ["Конец периода: 02.08.2026"], top, low,
            ["Диск", "A1", 101, 2, 200, None, None, 2, 200], ["Диск", "A2", 102, None, None, 3, 330, 3, 330]]
    loc = classify(Sheet(Path("Продажи за 3 месяца.xlsx"), "TDSheet", grid))
    amount, qty = read_sales(loc)
    assert qty == {"101": 2.0, "102": 3.0} and amount["102"] == 330.0  # итог, а не первый день
    assert read_sales_periods(loc)["102"] == [("2026-08-02", "2026-08-02", 3.0, 330.0)]
    # по месяцам и без «Итого»: сумма месяцев
    top = ["Товар", "Код", "Август 2026", "Август 2026", "Сентябрь 2026", "Сентябрь 2026"]
    low = ["Товар", "Код"] + ["Количество", "Сумма продажи"] * 2
    grid = [top, low, ["Диск", 101, 4, 400, 6, 600]]
    loc = classify(Sheet(Path("Продажи.xlsx"), "Лист1", grid))
    amount, qty = read_sales(loc)
    assert qty == {"101": 10.0} and amount == {"101": 1000.0}
    assert read_sales_periods(loc)["101"][1][:2] == ("2026-09-01", "2026-09-30")


def test_sales_trend_and_effect_of_a_price_change():
    from pricing import salestrend as T

    end = dt.date(2026, 10, 16)
    days = [((end - dt.timedelta(days=i)).isoformat(),) * 2 + (1.0 if i < 28 else 2.0, 100.0) for i in range(56)]
    recent, before, change = T.trend(days, end)
    assert recent == 28 and before == 56 and round(change, 2) == -0.5
    assert T.trend(days[:5], end)[2] is None  # базы нет
    text = T.effect_text(days, {"date": (end - dt.timedelta(days=27)).isoformat()}, end)
    assert "-50%" in text and "28 дн." in text
    assert T.effect_text(days, {"date": (end - dt.timedelta(days=5)).isoformat()}, end) == ""  # прошло мало дней
    month = [("2026-09-01", "2026-09-30", 30.0, 0.0)]
    assert round(T._amount(month, dt.date(2026, 9, 21), dt.date(2026, 9, 30)), 6) == 10.0
